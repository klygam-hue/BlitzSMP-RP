Blitz SMP 26.3 VisualPack v5 + BlitzCameras

Custom resources only. Standard Minecraft textures, models, shaders,
languages, fonts, sounds and other unmodified client assets are not bundled.
The client provides its normal resources. Atlas files contain only the
additional mod entries, which Minecraft merges with its own atlas sources.

Target: Minecraft Java 26.3; resource-pack format 97.1.
Includes the existing mod visual assets, custom train hat attachments and
all camera/computer/control textures. The separate camera pack is not needed.
Enable this ZIP instead of older full packs.

Create/Flywheel/Ponder/Copycats/Vanillin custom mechanics and model types need
matching client mods. The resource pack does not install or port mod code.
Engine decoding and ShaderC checks do not replace visual gameplay testing.
