Blitz SMP 26.3 VisualPack v6 + BlitzCameras 1.0.1

Custom resources only; no standard vanilla textures are bundled.
Use with BlitzCameras 1.0.1 for the native skull skin fix. The real head block
uses its own texture instead of a display entity over a default player head.
Includes six 64x64 head skin assets with a transparent outer hat layer.
The plugin updates existing devices automatically on chunk load.

Target: Minecraft Java 26.3, resource-pack format 97.1.
Enable this ZIP instead of older packs; a separate camera pack is not needed.
Existing mod resources are preserved. Custom mod item types and mechanics
still need matching client mods for 26.3. Visual gameplay and mod renderer
runtime testing were not performed.
