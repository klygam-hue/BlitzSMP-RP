Blitz SMP 26.3 VisualPack v4 + BlitzCameras

Target: Minecraft Java 26.3, resource-pack format 97.1.

The vanilla layer has been rebased onto the locally installed official 26.3
client assets. The old 26.2 vanilla shaders, model definitions, palettes,
equipment, atlases and removed resources are no longer used as the base.
The original mod namespaces, train hat attachments, pack icon and all camera
assets are retained. Cuboid shading, mod atlas palettes, entity armor trim
metadata/equipment overrides and four Mojang-importing mod shaders were
migrated to the 26.3 format.

Enable this ZIP instead of the older pack. Do not enable the old 26.2 pack
above it. BlitzCameras does not need a second resource pack.

This is a resource pack, not a mod loader or a mod port. Create, Flywheel,
Ponder, Copycats and other mod-specific mechanics/custom model types still
need matching client mods for Minecraft 26.3. Vanilla/Paper clients can use
the standard resources and BlitzCameras without these mods.

Verification details are supplied beside this ZIP. Static validation and
engine codecs do not replace gameplay testing of the mod renderers.

Vanilla assets are Mojang assets. Use within the same licensed server/client
context as the original pack.
